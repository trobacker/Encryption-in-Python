def addNumbers(a, b):
    return a + b

spam = addNumbers(2, 40)
print(spam)